/**
 * My To Do List App
 *
 * @format
 */

import React from 'react';

import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View
} from 'react-native';

import { SafeAreaView } from 'react-native-safe-area-context';

export default function ToDoList({ tasks }) {
  return (
    <SafeAreaView>
      <ScrollView>
        <Pressable>
          {tasks.map((task) => {
          return (
            <View style={styles.task} key={task}>
              <Text>{task}</Text>
            </View>
          )
        })}
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  task: {
    padding: 10,
    borderBottomWidth: 1,
    borderColor: '#ccc',
  },
  completed: {
    backgroundColor: '#e0e0e0',
  },
  taskText: {
    fontSize: 16,
  },
});
