/**
 * My To Do List App
 *
 * @format
 */

import { useState } from 'react';
import { View } from 'react-native';
import ToDoForm from './ToDoForm';
import ToDoList from './ToDoList';

export default function Index() {

  console.log(ToDoList);

  const [tasks] = useState([
    'Do laundry',
    'Go to gym',
    'Walk dog'
  ])

  return (
    <View>
      <ToDoList tasks={tasks} />
      <ToDoForm />
    </View>
  );
}